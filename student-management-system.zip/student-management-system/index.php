<?php
declare(strict_types=1);
session_start();

$host = '127.0.0.1';
$db   = 'student_management';
$user = 'root';
$pass = ''; // Change this if your local MySQL account has a password.
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check the database settings in index.php and import database.sql.');
}

function h(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

$errors = [];
$editStudent = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $course = trim($_POST['course'] ?? '');
    $year = filter_var($_POST['year'] ?? '', FILTER_VALIDATE_INT);

    if ($action === 'save') {
        if ($name === '') $errors[] = 'Name is required.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if ($course === '') $errors[] = 'Course is required.';
        if ($year === false || $year < 1 || $year > 6) $errors[] = 'Year of study must be between 1 and 6.';

        if (!$errors) {
            $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
            if ($id) {
                $stmt = $pdo->prepare('UPDATE students SET name = ?, email = ?, course = ?, year_of_study = ? WHERE id = ?');
                $stmt->execute([$name, $email, $course, $year, $id]);
                $_SESSION['flash'] = 'Student details updated successfully.';
            } else {
                try {
                    $stmt = $pdo->prepare('INSERT INTO students (name, email, course, year_of_study) VALUES (?, ?, ?, ?)');
                    $stmt->execute([$name, $email, $course, $year]);
                    $_SESSION['flash'] = 'Student added successfully.';
                } catch (PDOException $e) {
                    if ($e->getCode() === '23000') {
                        $errors[] = 'That email address is already registered.';
                    } else {
                        throw $e;
                    }
                }
            }
            if (!$errors) {
                header('Location: index.php');
                exit;
            }
        }
    } elseif ($action === 'delete') {
        $id = filter_var($_POST['id'] ?? '', FILTER_VALIDATE_INT);
        if ($id) {
            $stmt = $pdo->prepare('DELETE FROM students WHERE id = ?');
            $stmt->execute([$id]);
            $_SESSION['flash'] = 'Student deleted.';
        }
        header('Location: index.php');
        exit;
    }
}

if (isset($_GET['edit'])) {
    $id = filter_var($_GET['edit'], FILTER_VALIDATE_INT);
    if ($id) {
        $stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
        $stmt->execute([$id]);
        $editStudent = $stmt->fetch() ?: null;
    }
}

$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $stmt = $pdo->prepare('SELECT * FROM students WHERE name LIKE ? OR email LIKE ? OR course LIKE ? ORDER BY created_at DESC');
    $term = '%' . $search . '%';
    $stmt->execute([$term, $term, $term]);
    $students = $stmt->fetchAll();
} else {
    $students = $pdo->query('SELECT * FROM students ORDER BY created_at DESC')->fetchAll();
}
$totalStudents = (int) $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();
$flash = $_SESSION['flash'] ?? '';
unset($_SESSION['flash']);

$form = $editStudent ?? ['id' => '', 'name' => '', 'email' => '', 'course' => '', 'year_of_study' => 1];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
    <div class="brand"><span class="brand-mark">S</span><div><strong>CampusDesk</strong><small>Student Management</small></div></div>
    <span class="top-note">Student records dashboard</span>
</header>

<main class="container">
    <section class="welcome">
        <div>
            <p class="eyebrow">ADMIN DASHBOARD</p>
            <h1>Manage your students</h1>
            <p class="subheading">Add, search, update, and remove student records in one place.</p>
        </div>
        <div class="stat-card"><span class="stat-label">Total students</span><strong><?= $totalStudents ?></strong><span class="stat-caption">Records in the system</span></div>
    </section>

    <?php if ($flash): ?><div class="notice success"><?= h($flash) ?></div><?php endif; ?>
    <?php if ($errors): ?><div class="notice error"><strong>Please fix the following:</strong><ul><?php foreach ($errors as $error): ?><li><?= h($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

    <section class="content-grid">
        <article class="panel form-panel">
            <div class="panel-heading"><div><p class="eyebrow"><?= $editStudent ? 'EDIT RECORD' : 'NEW RECORD' ?></p><h2><?= $editStudent ? 'Update student' : 'Add a student' ?></h2></div><span class="heading-icon">＋</span></div>
            <form method="post" action="index.php" class="student-form">
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" value="<?= h((string)$form['id']) ?>">
                <label for="name">Full name</label>
                <input id="name" name="name" type="text" maxlength="120" placeholder="e.g. Amina Wanjiku" value="<?= h((string)$form['name']) ?>" required>
                <label for="email">Email address</label>
                <input id="email" name="email" type="email" maxlength="190" placeholder="student@example.com" value="<?= h((string)$form['email']) ?>" required>
                <label for="course">Course / programme</label>
                <input id="course" name="course" type="text" maxlength="120" placeholder="e.g. Applied Computer Science" value="<?= h((string)$form['course']) ?>" required>
                <label for="year">Year of study</label>
                <select id="year" name="year" required>
                    <?php for ($i = 1; $i <= 6; $i++): ?>
                    <option value="<?= $i ?>" <?= (int)$form['year_of_study'] === $i ? 'selected' : '' ?>>Year <?= $i ?></option>
                    <?php endfor; ?>
                </select>
                <button class="button primary" type="submit"><?= $editStudent ? 'Save changes' : 'Add student' ?></button>
                <?php if ($editStudent): ?><a class="cancel-link" href="index.php">Cancel editing</a><?php endif; ?>
            </form>
        </article>

        <article class="panel records-panel">
            <div class="records-heading"><div><p class="eyebrow">STUDENT DIRECTORY</p><h2>Student records</h2></div><span class="record-count"><?= count($students) ?> shown</span></div>
            <form class="search-form" method="get" action="index.php">
                <span class="search-symbol">⌕</span>
                <input type="search" name="search" value="<?= h($search) ?>" placeholder="Search name, email, or course..." aria-label="Search students">
                <button class="button search-button" type="submit">Search</button>
                <?php if ($search !== ''): ?><a class="clear-search" href="index.php">Clear</a><?php endif; ?>
            </form>

            <?php if (!$students): ?>
                <div class="empty-state"><div class="empty-icon">▤</div><h3>No student records found</h3><p><?= $search ? 'Try another search term.' : 'Add your first student using the form.' ?></p></div>
            <?php else: ?>
                <div class="table-wrap"><table>
                    <thead><tr><th>Student</th><th>Course</th><th>Year</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><div class="student-name"><?= h($student['name']) ?></div><div class="student-email"><?= h($student['email']) ?></div></td>
                            <td><?= h($student['course']) ?></td>
                            <td><span class="year-pill">Year <?= (int)$student['year_of_study'] ?></span></td>
                            <td><div class="actions"><a class="edit-link" href="index.php?edit=<?= (int)$student['id'] ?>">Edit</a>
                                <form method="post" action="index.php" class="delete-form" onsubmit="return confirm('Delete this student record?');">
                                    <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$student['id'] ?>">
                                    <button class="delete-link" type="submit">Delete</button>
                                </form></div></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
            <?php endif; ?>
        </article>
    </section>
    <footer>CampusDesk Student Management System <span>•</span> Built with PHP, MySQL, HTML, and CSS</footer>
</main>
</body>
</html>
