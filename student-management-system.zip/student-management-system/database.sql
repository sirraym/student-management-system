CREATE DATABASE IF NOT EXISTS student_management
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE student_management;

CREATE TABLE IF NOT EXISTS students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    course VARCHAR(120) NOT NULL,
    year_of_study TINYINT UNSIGNED NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_year_of_study CHECK (year_of_study BETWEEN 1 AND 6)
);

-- Optional sample data for testing. Use unique email addresses.
INSERT INTO students (name, email, course, year_of_study) VALUES
('Amina Wanjiku', 'amina@example.com', 'Applied Computer Science', 2),
('Brian Otieno', 'brian@example.com', 'Information Technology', 3);
