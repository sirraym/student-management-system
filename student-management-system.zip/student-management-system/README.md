# CampusDesk — Student Management System

A beginner-friendly CRUD web application for managing student records. It was built as a learning project using PHP, MySQL, HTML, and CSS.

## Features

- Add student records
- List and search by name, email, or course
- Edit existing records
- Delete records after confirmation
- Validate required fields and email addresses
- Prevent duplicate email addresses
- Use prepared SQL statements for database operations
- Responsive layout for desktop and mobile

## Requirements

- PHP 8.0 or later with PDO MySQL enabled
- MySQL 5.7+ or MariaDB
- A local server such as XAMPP, WAMP, or MAMP
- Git and a GitHub account (for publishing the repository)

## Run locally with XAMPP

1. Copy this project folder into your XAMPP `htdocs` directory.
2. Start **Apache** and **MySQL** in the XAMPP control panel.
3. Open phpMyAdmin at `http://localhost/phpmyadmin`.
4. Select **Import**, choose `database.sql`, and run the import.
5. If your MySQL username/password differs from the defaults, update `$user` and `$pass` near the top of `index.php`.
6. Visit `http://localhost/student-management-system/`.

The default configuration assumes MySQL user `root` with an empty password, which is common in a fresh local XAMPP setup. Change it if needed.

## Project structure

```text
student-management-system/
├── index.php       # Application UI, validation, and CRUD logic
├── style.css       # Responsive styling
├── database.sql    # Database and table setup plus sample records
├── README.md       # Setup and project documentation
└── .gitignore      # Common local files to ignore
```

## Publish to GitHub

1. Create a new **public** repository named `student-management-system` on GitHub.
2. In your terminal, change directory into this project.
3. Run:

```bash
git init
git add index.php style.css database.sql README.md .gitignore
git commit -m "Build student management system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/student-management-system.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to sign in, follow GitHub's authentication instructions.

## Suggested improvements

- Add login and role-based access
- Add pagination for large directories
- Add unit and integration tests
- Add CSRF protection to form submissions
- Move database credentials into environment variables
- Add a student details page and CSV export

## Learning notes

Before using this as a work sample, run it yourself, understand the code, test every feature, and make at least a few meaningful changes. In the Rex application, describe the parts you actually built and the tools you genuinely used. Do not claim professional deployment or contributions you have not made.
